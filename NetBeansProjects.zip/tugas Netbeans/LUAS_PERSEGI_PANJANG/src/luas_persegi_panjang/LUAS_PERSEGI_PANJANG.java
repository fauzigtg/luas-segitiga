/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package luas_persegi_panjang;

/**
 *
 * @author ASUS
 */
public class LUAS_PERSEGI_PANJANG {
      
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        double p=5, l=10, luas;
        //hitung
        luas=p*l;
        //hasil
        System.out.println("===MENGHITUNG LUAS PP===");
        System.out.println("panjang\t="+p"cm");
        System.out.println("lebar\t="+l+"cm");
        System.out.println("luas\t=PxL");
        System.out.println("\t="+luas+"cm2");
        
    }
    
}
